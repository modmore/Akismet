<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '#Akismet: Spam Protection for MODX

Developed by [modmore](https://modmore.com)

Introduction
-

[Akismet](https://akismet.com/) is an advanced spam protection service that uses AI to analyse form submissions. 
Originally developed for Wordpress, this open source package integrates Akismet with the MODX extras
[FormIt](https://docs.modx.com/current/en/extras/formit/index) and [Login](https://docs.modx.com/current/en/extras/login/index) (specifically the [Register](https://docs.modx.com/current/en/extras/login/login.register) snippet).

The provided MODX snippet ***akismet*** is used as a *[hook](https://docs.modx.com/3.x/en/extras/formit/formit.hooks)* with FormIt, and a *[preHook](https://docs.modx.com/3.x/en/extras/login/login.tutorials/using-pre-and-post-hooks)* with Register.

Installation
-
Install Akismet via the [modmore package provider](https://modmore.com/about/package-provider/). Sign up for an Akismet account [here](https://akismet.com/plans/), then copy and paste the provided *API Key* into the new `akismet.api_key` system setting.  


Usage with FormIt
-
Within your FormIt snippet call, add `akismet` as one of your hooks. Preferably the first one, as to prevent other hooks running if spam is detected.

```
[[!FormIt? 
    &hooks=`akismet,email,redirect`
    ...
]]
```

Usage with Login
-
Within your Register snippet call, add `akismet` as one of your *preHooks*.

```
[[!Register?
    &preHooks=`akismet`
    ...
]]
```

Configurable Fields
-
Since Akismet was originally developed for Wordpress, it accepts fields that are related to comments on blog posts, 
such as `comment_author`, `comment_author_email` and `comment_content`.

Since MODX allows any naming convention for fields, you can set the names as snippet parameters. This works with both FormIt and Register.

Say for example, you have a contact form with the following fields: `name`, `email` and `message`. 
You can set these to the fields that the Akismet service is expecting. See this code example:

```
[[!FormIt? 
    &hooks=`akismet,email,redirect`
    &akismetAuthor=`name`
    &akismetAuthorEmail=`email`
    &akismetContent=`message`
    ...
]]
```

**Complete List of Parameters**

- `&akismetAuthor` - The author\'s name.
- `&akismetAuthorEmail` - The author\'s email.
- `&akismetAuthorUrl` - The author\'s URL if they provided one.
- `&akismetContent` - The message content.
- `&akismentType` - The type of form submitted. Available types include *comment*, *forum-post*, *reply*, *blog-post*, *contact-form*, *signup*, *message*, and more. Read more [here](https://blog.akismet.com/2012/06/19/pro-tip-tell-us-your-comment_type/).
- `&akismetUserRole` - The type of user e.g. *visitor*, or *member*. If set to *Administrator*, the form will never be blocked.
- `&akismetTest` - Set this to `1` while developing so the AI knows it is just a test submission.
- `&akismetHoneypotField` - If you use a hidden honeypot field in your form, set the name of it here.
- `&akismetRecheckReason` - If you have a form where the same submission needs to be checked more than once, include the reason for it here.',
    'changelog' => 'Akismet 1.0.0-rc1
---------------------------------
Released on 2021-09-06

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '55ff93e9864e3f93e4dcdc7feb8b7928',
      'native_key' => 'akismet',
      'filename' => 'modNamespace/1c712bd33da3209f784e4a18057f4b4d.vehicle',
      'namespace' => 'akismet',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '6d78ae2ef2d8674840e1a4defd8aec77',
      'native_key' => '6d78ae2ef2d8674840e1a4defd8aec77',
      'filename' => 'xPDOFileVehicle/b114cea65b7e56bdde3cd5543f24d7d2.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9eb1b5654d5eceabb76217efd944de7b',
      'native_key' => '9eb1b5654d5eceabb76217efd944de7b',
      'filename' => 'xPDOFileVehicle/8e601b29dfeed43a6598b197b6fd542d.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e2e5957696fc630aef1b7a0c48546cb',
      'native_key' => 'akismet.assets_path',
      'filename' => 'modSystemSetting/fa9eccb7e8d491da972cbce31bb015cf.vehicle',
      'namespace' => 'akismet',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffb2ac861089b8e3213881a58e5cac3e',
      'native_key' => 'akismet.assets_url',
      'filename' => 'modSystemSetting/be457d867afe90dea5f32e9c63f3539b.vehicle',
      'namespace' => 'akismet',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4bcb4f00b7782cda390e5f6886aedfa',
      'native_key' => 'akismet.core_path',
      'filename' => 'modSystemSetting/b982cc48fea3f7ef9f978638943f6c5f.vehicle',
      'namespace' => 'akismet',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87dfb9d971d3e95c8b05b9c6a0c31381',
      'native_key' => 'akismet.api_key',
      'filename' => 'modSystemSetting/e7b5fc000f8783adc6fedc8d1f4b8182.vehicle',
      'namespace' => 'akismet',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a98092299bcf4dc6fbb6c87911a4005b',
      'native_key' => 'akismet',
      'filename' => 'modMenu/db065296d74722808a92f20f4e376c42.vehicle',
      'namespace' => 'akismet',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9f71971efb0b0756a9fa89e7507337ae',
      'native_key' => NULL,
      'filename' => 'modCategory/f2c4ff91fb27b3ac0f2c47b9977567b6.vehicle',
      'namespace' => 'akismet',
    ),
  ),
);