<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '#Akismet: Spam Protection for MODX

Developed by [modmore](https://modmore.com)

Introduction
-

[Akismet](https://akismet.com/) is an advanced spam protection service that uses AI to analyse form submissions. 
Originally developed for Wordpress, this open source package integrates Akismet with the MODX extras
[FormIt](https://docs.modx.com/current/en/extras/formit/index) and [Login](https://docs.modx.com/current/en/extras/login/index) (specifically the [Register](https://docs.modx.com/current/en/extras/login/login.register) snippet).

The provided MODX snippet ***akismet*** is used as a *[hook](https://docs.modx.com/3.x/en/extras/formit/formit.hooks)* with FormIt, and a *[preHook](https://docs.modx.com/3.x/en/extras/login/login.tutorials/using-pre-and-post-hooks)* with Register.

Installation
-
Install Akismet via the [modmore package provider](https://modmore.com/about/package-provider/). Sign up for an Akismet account [here](https://akismet.com/plans/), then copy and paste the provided *API Key* into the new `akismet.api_key` system setting.  


Usage with FormIt
-
Within your FormIt snippet call, add `akismet` as one of your hooks. Preferably the first one, as to prevent other hooks running if spam is detected.

```
[[!FormIt? 
    &hooks=`akismet,email,redirect`
    ...
]]
```

Usage with Login
-
Within your Register snippet call, add `akismet` as one of your *preHooks*.

```
[[!Register?
    &preHooks=`akismet`
    ...
]]
```

Configurable Fields
-
Since Akismet was originally developed for Wordpress, it accepts fields that are related to comments on blog posts, 
such as `comment_author`, `comment_author_email` and `comment_content`.

Since MODX allows any naming convention for fields, you can set the names as snippet parameters. This works with both FormIt and Register.

Say for example, you have a contact form with the following fields: `name`, `email` and `message`. 
You can set these to the fields that the Akismet service is expecting. See this code example:

```
[[!FormIt? 
    &hooks=`akismet,email,redirect`
    &akismetAuthor=`name`
    &akismetAuthorEmail=`email`
    &akismetContent=`message`
    ...
]]
```

**Complete List of Parameters**

- `&akismetAuthor` - The author\'s name.
- `&akismetAuthorEmail` - The author\'s email.
- `&akismetAuthorUrl` - The author\'s URL if they provided one.
- `&akismetContent` - The message content.
- `&akismentType` - The type of form submitted. Available types include *comment*, *forum-post*, *reply*, *blog-post*, *contact-form*, *signup*, *message*, and more. Read more [here](https://blog.akismet.com/2012/06/19/pro-tip-tell-us-your-comment_type/).
- `&akismetUserRole` - The type of user e.g. *visitor*, or *member*. If set to *Administrator*, the form will never be blocked.
- `&akismetTest` - Set this to `1` while developing so the AI knows it is just a test submission.
- `&akismetHoneypotField` - If you use a hidden honeypot field in your form, set the name of it here.
- `&akismetRecheckReason` - If you have a form where the same submission needs to be checked more than once, include the reason for it here.',
    'changelog' => 'Akismet 1.0.0-rc1
---------------------------------
Released on 2021-09-06

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a906753afae3de5a6791eed68a67234d',
      'native_key' => 'akismet',
      'filename' => 'modNamespace/6ab7a4d2945adb02531bcce780bc577f.vehicle',
      'namespace' => 'akismet',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '2b7019e4c82279f746fe5fb7a6f3a713',
      'native_key' => '2b7019e4c82279f746fe5fb7a6f3a713',
      'filename' => 'xPDOFileVehicle/5b77cba0ebd5bce5809e24ea7462d7b0.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '22ee4183c9b7077ceb41906c16fc9ffb',
      'native_key' => '22ee4183c9b7077ceb41906c16fc9ffb',
      'filename' => 'xPDOFileVehicle/b928d4b6d3d63b93daa007dc0e8897a1.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af9cc7a29432254127118a31081a209f',
      'native_key' => 'akismet.assets_path',
      'filename' => 'modSystemSetting/a0c3105f61d822b2d45cf5b07948caef.vehicle',
      'namespace' => 'akismet',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85125c6029e4fd81cc9809a078eade68',
      'native_key' => 'akismet.assets_url',
      'filename' => 'modSystemSetting/91d801bdd0e5f621ed9922e44b652201.vehicle',
      'namespace' => 'akismet',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1883bcf68355a7249d8fc1286d4f4faa',
      'native_key' => 'akismet.core_path',
      'filename' => 'modSystemSetting/5f44f56b816b2f5e07fbb38c9ea116d4.vehicle',
      'namespace' => 'akismet',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a700df68b78654606f819acecd61550',
      'native_key' => 'akismet.api_key',
      'filename' => 'modSystemSetting/ab597e56a1e6718fee5672069142100a.vehicle',
      'namespace' => 'akismet',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '30b1019f34c1e2453e16c531cc3f90e4',
      'native_key' => 'akismet',
      'filename' => 'modMenu/6ff2e1ed890478243436fb5206c06512.vehicle',
      'namespace' => 'akismet',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ba6aa46d211acf91d8f8f97f08dbf942',
      'native_key' => NULL,
      'filename' => 'modCategory/2921c57d9e70d84cbd56735a824053f0.vehicle',
      'namespace' => 'akismet',
    ),
  ),
);