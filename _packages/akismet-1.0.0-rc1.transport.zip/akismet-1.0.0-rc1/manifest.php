<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Akismet
-------

A short description of what Akismet does or how to set it up.

',
    'changelog' => 'Akismet 1.0.0-rc1
---------------------------------
Released on

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c32a208061faf26bcb0189e2668734d4',
      'native_key' => 'akismet',
      'filename' => 'modNamespace/82fba339165a9619fb07f0a73d6a135f.vehicle',
      'namespace' => 'akismet',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '41405069af4db3123959701f8d268c58',
      'native_key' => '41405069af4db3123959701f8d268c58',
      'filename' => 'xPDOFileVehicle/dad4296688ef75c8739e8a80fda30cc1.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '8c5269f2611b9717081e9358939e8761',
      'native_key' => '8c5269f2611b9717081e9358939e8761',
      'filename' => 'xPDOFileVehicle/190b2e26a7e0765c8840fadda283a18b.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e3e7bed6020f89062ab168583d26eda',
      'native_key' => 'akismet.assets_path',
      'filename' => 'modSystemSetting/29ef7b7283f502ad6aa161904da36ffe.vehicle',
      'namespace' => 'akismet',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f812332e726f9d37e1e993d2a5b4e33c',
      'native_key' => 'akismet.assets_url',
      'filename' => 'modSystemSetting/6bcd71e0c27c07d0746a7e3c4328f1dc.vehicle',
      'namespace' => 'akismet',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81802cee0301057cf5e6189e2bd284d6',
      'native_key' => 'akismet.core_path',
      'filename' => 'modSystemSetting/f85c39da304dfd4edb389646c4de6136.vehicle',
      'namespace' => 'akismet',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '101fbf94b82f61bef18e87f487181d59',
      'native_key' => 'akismet.api_key',
      'filename' => 'modSystemSetting/4af0f7cb79b751587ae0faab45667d06.vehicle',
      'namespace' => 'akismet',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9b01fadc8da094486592d7d92d6c1237',
      'native_key' => 'akismet',
      'filename' => 'modMenu/27bf8ccd0863be92681c18eb48bf659e.vehicle',
      'namespace' => 'akismet',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3677ef294142b925a9b713f85902c921',
      'native_key' => NULL,
      'filename' => 'modCategory/d5328e08356a1d3bbad5d031bf8ecb1c.vehicle',
      'namespace' => 'akismet',
    ),
  ),
);