<?php
/**
 * Akismet for MODX.
 *
 * Copyright 2021 by modmore
 *
 * @package akismet
 * @license See core/components/akismet/docs/license.txt
 */
class AkismetForm extends xPDOSimpleObject
{

}
