<?php

namespace modmore\Akismet\Exceptions;

class InvalidAPIKeyException extends \Exception
{

}