Akismet: Spam Protection for MODX

Akismet (https://akismet.com/) is an advanced spam protection service that uses AI to analyse form submissions. Originally developed for Wordpress, this open source package integrates Akismet with FormIt, Register, and Quip.

For detailed usage instructions, please find the documentation at: https://docs.modmore.com/en/Open_Source/Akismet/index.html

To support our work on open source projects like Akismet, please consider making a donation via: https://modmore.com/extras/akismet/donate/
