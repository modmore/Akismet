<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2021

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Akismet: Spam Protection for MODX

Akismet (https://akismet.com/) is an advanced spam protection service that uses AI to analyse form submissions. Originally developed for Wordpress, this open source package integrates Akismet with FormIt, Register, and Quip.

For detailed usage instructions, please find the documentation at: https://docs.modmore.com/en/Open_Source/Akismet/index.html

To support our work on open source projects like Akismet, please consider making a donation via: https://modmore.com/extras/akismet/donate/
',
    'changelog' => 'Akismet 1.2.1-pl
---------------------------------
Released on 2021-11-12

- Avoid division by zero fatal error on Akismet manager page if there are no stats yet.

Akismet 1.2.0-pl
---------------------------------
Released on 2021-10-02

- Track total spam/real messages and spam percentage, and show in component

Akismet 1.1.0-pl
---------------------------------
Released on 2021-09-16

- Fix honeypot implementation. [#2]
- Fix errors not being logged correctly from within the snippet.
- Add support for compound fields [#4]
- Automatically remove records after a specified time period [#5]
- Refactor Akismet class to allow for compatibility with snippets/scripts [#7]
- Make Akismet compatible with Quip. Needs to be a preHook on the QuipReply snippet. [#6]
- If you want to see the raw parameters sent to Akismet and the verdict, set the akismet.debug system setting to 1.

Akismet 1.0.1-pl
---------------------------------
Released on 2021-09-08

- Support proxied IP addresses with X-Forwarded-For header [#3]
- Fix database schema not allowing for IPv6 addresses

Akismet 1.0.0-pl
---------------------------------
Released on 2021-09-07

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1b70ca48f3f88be9f12bc7024fb15636',
      'native_key' => 'akismet',
      'filename' => 'modNamespace/a05ce6774420f26716b32a059da646c7.vehicle',
      'namespace' => 'akismet',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b14c2785f15134a8320679c4d190e5b8',
      'native_key' => 'b14c2785f15134a8320679c4d190e5b8',
      'filename' => 'xPDOFileVehicle/38968f27138b918f3a9bbf29283a0d9c.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c053b5d06b18dd180ec0a33d9900f41e',
      'native_key' => 'c053b5d06b18dd180ec0a33d9900f41e',
      'filename' => 'xPDOFileVehicle/f556e89996104b019f25b99db613ef0b.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c47f8e6a5d725b461aaee50d0af55a5',
      'native_key' => 'akismet.assets_path',
      'filename' => 'modSystemSetting/a3d39855ead978e046e62c055649a8db.vehicle',
      'namespace' => 'akismet',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b38fe320466bf5b4eac758f21729ced',
      'native_key' => 'akismet.assets_url',
      'filename' => 'modSystemSetting/f555419cd0214abb89412f58c7610639.vehicle',
      'namespace' => 'akismet',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a80f96752e3e4cd8b01f8d6ec185c7c',
      'native_key' => 'akismet.core_path',
      'filename' => 'modSystemSetting/2e6bbd1069bb76ed4c0263706c108be2.vehicle',
      'namespace' => 'akismet',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f3b4364b7a5c2d22ecaa36fd9309094',
      'native_key' => 'akismet.api_key',
      'filename' => 'modSystemSetting/ed1ad6cb16b3a413a3d7ff8f46f09004.vehicle',
      'namespace' => 'akismet',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '292ecdaa352bbc2254f7614fcd459fb7',
      'native_key' => 'akismet.cleanup_days_old',
      'filename' => 'modSystemSetting/c8ea8f364785ec83a503ad427187dedc.vehicle',
      'namespace' => 'akismet',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1073807ec6960b40c18064204253f5a',
      'native_key' => 'akismet.debug',
      'filename' => 'modSystemSetting/0e7ec7ef44c306afc94dea65a02ada70.vehicle',
      'namespace' => 'akismet',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb40c5ff6a6b898abdafba806c4760cf',
      'native_key' => 'akismet.total_spam',
      'filename' => 'modSystemSetting/64978d583d07dd50adc505b45ee9bfe7.vehicle',
      'namespace' => 'akismet',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5af8d585e70576ea0ca3ea85a1798e07',
      'native_key' => 'akismet.total_ham',
      'filename' => 'modSystemSetting/da723bf58d30174890f4eea335c69e75.vehicle',
      'namespace' => 'akismet',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5fa1dfc4076cfab2e8f945b746f18e0e',
      'native_key' => 'akismet',
      'filename' => 'modMenu/af29cbb5ff1536fd6542de8486d18b04.vehicle',
      'namespace' => 'akismet',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '407b9cc7cc150efed075c8708682a1b7',
      'native_key' => NULL,
      'filename' => 'modCategory/155daee8f5f4027c85cb1cd084eda407.vehicle',
      'namespace' => 'akismet',
    ),
  ),
);