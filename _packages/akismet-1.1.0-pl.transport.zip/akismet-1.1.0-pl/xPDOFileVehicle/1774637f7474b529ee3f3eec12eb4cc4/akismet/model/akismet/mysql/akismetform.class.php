<?php
require_once strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/akismetform.class.php';
/**
 * Akismet for MODX
 *
 * Copyright 2021 by modmore
 *
 * @package akismet
 * @license See core/components/akismet/docs/license.txt
 */
class AkismetForm_mysql extends AkismetForm
{

}
