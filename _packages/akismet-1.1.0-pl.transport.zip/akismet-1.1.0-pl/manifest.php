<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2021

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Akismet: Spam Protection for MODX

Akismet (https://akismet.com/) is an advanced spam protection service that uses AI to analyse form submissions. Originally developed for Wordpress, this open source package integrates Akismet with FormIt, Register, and Quip.

For detailed usage instructions, please find the documentation at: https://docs.modmore.com/en/Open_Source/Akismet/index.html

To support our work on open source projects like Akismet, please consider making a donation via: https://modmore.com/extras/akismet/donate/
',
    'changelog' => 'Akismet 1.1.0-pl
---------------------------------
Released on 2021-09-16

- Fix honeypot implementation. [#2]
- Fix errors not being logged correctly from within the snippet.
- Add support for compound fields [#4]
- Automatically remove records after a specified time period [#5]
- Refactor Akismet class to allow for compatibility with snippets/scripts [#7]
- Make Akismet compatible with Quip. Needs to be a preHook on the QuipReply snippet. [#6]
- If you want to see the raw parameters sent to Akismet and the verdict, set the akismet.debug system setting to 1.

Akismet 1.0.1-pl
---------------------------------
Released on 2021-09-08

- Support proxied IP addresses with X-Forwarded-For header [#3]
- Fix database schema not allowing for IPv6 addresses

Akismet 1.0.0-pl
---------------------------------
Released on 2021-09-07

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '11fef73cd52c0cb3157fe4738f6c805d',
      'native_key' => 'akismet',
      'filename' => 'modNamespace/e2002d43b70569c741fdf5f7510c63a5.vehicle',
      'namespace' => 'akismet',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '7e3a81ea0338f69c55141591c6fea63d',
      'native_key' => '7e3a81ea0338f69c55141591c6fea63d',
      'filename' => 'xPDOFileVehicle/1774637f7474b529ee3f3eec12eb4cc4.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '60be672cc319b32a6938e5365037458c',
      'native_key' => '60be672cc319b32a6938e5365037458c',
      'filename' => 'xPDOFileVehicle/78abb3862592dc17c089fdc0c0cf0f81.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2a676ef7d4724c3a51279a7d0c9a6ff',
      'native_key' => 'akismet.assets_path',
      'filename' => 'modSystemSetting/a81de9e77e00e9aa37427760723f8003.vehicle',
      'namespace' => 'akismet',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '982ec8104048b40af620905439a1a1d6',
      'native_key' => 'akismet.assets_url',
      'filename' => 'modSystemSetting/f27104fb550670d4b2f1e05c3afe0bbc.vehicle',
      'namespace' => 'akismet',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cabbb65c9466fed1e92233513b1486e',
      'native_key' => 'akismet.core_path',
      'filename' => 'modSystemSetting/88585a21edf72b33d701b479c33bf5fd.vehicle',
      'namespace' => 'akismet',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51f7f6e3de1f9477338425514368c1f8',
      'native_key' => 'akismet.api_key',
      'filename' => 'modSystemSetting/2f47c4e70e9990f8a2d7a3d74d362a7d.vehicle',
      'namespace' => 'akismet',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da277b71a2b0c354447dd63e96ceb8bb',
      'native_key' => 'akismet.cleanup_days_old',
      'filename' => 'modSystemSetting/46e6a1a80a3f778c659a5bdacb6835d3.vehicle',
      'namespace' => 'akismet',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce1c7826108063e8618598529db7ccd8',
      'native_key' => 'akismet.debug',
      'filename' => 'modSystemSetting/9c4318ca42ca7464c0baad8c9fdb99a2.vehicle',
      'namespace' => 'akismet',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0977859bbfb4366af40272da54272dff',
      'native_key' => 'akismet',
      'filename' => 'modMenu/adbd506e4f1c0915eff39abe1ec1fb9b.vehicle',
      'namespace' => 'akismet',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ef2c2a617393c69fed644c68476c1747',
      'native_key' => NULL,
      'filename' => 'modCategory/4525c23f04620fa900e9e02b3c68872b.vehicle',
      'namespace' => 'akismet',
    ),
  ),
);